<script lang="ts" setup>

</script>

<template>
  <div class="app-container">
    案例展示 一
  </div>
</template>

<style lang="scss" scoped>

</style>
